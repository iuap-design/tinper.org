import {extend} from 'tinper-sparrow/src/extend';
import {BaseComponent} from 'tinper-neoui/src/neoui-BaseComponent';import {u} from 'tinper-sparrow/src/index';import * as compox from 'compox/src/index';import * as compox_util from 'compox-util/src/index';
import {Checkbox} from 'tinper-neoui/src/neoui-checkbox';

import {BaseAdapter} from 'neoui-kero/src/keroa-baseAdapter';
import {CheckboxAdapter} from 'neoui-kero/src/keroa-checkbox';
import {DataTable, u as kero} from 'kero/src/index';
var ex = {"Checkbox":Checkbox,"CheckboxAdapter":CheckboxAdapter}
extend(ex,window.u || {});
window.u = ex;
export {ex as u};