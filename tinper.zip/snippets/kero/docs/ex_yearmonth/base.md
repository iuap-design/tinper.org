# 年月选择

本例展示:年月UI控件绑定默认数据。

[试一试](http://tinper.org/webide/#/demos/kero/yearmonth)


# API

## \# u-meta 属性

* type：`u-yearmonth`

u-meta基础api请参考[这里](http://tinper.org/dist/kero/docs/moduleapi.html)

相关内容：

[基础年月控件](http://tinper.org/dist/neoui/plugin/yearmonth.html)    

[年月控件在grid中使用](http://tinper.org/webide/#/demos/grids/edit)
