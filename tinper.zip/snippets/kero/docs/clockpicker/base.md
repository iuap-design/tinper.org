# 表盘选择

本例展示kero与表盘clockpicker结合示例。

