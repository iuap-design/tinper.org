# 多行文本输入控件

本例展示kero与多行文本输入控件textarea结合示例。

[试一试](http://tinper.org/webide/#/demos/kero/textarea)


# API

## \# u-meta 属性

* type：`textarea`