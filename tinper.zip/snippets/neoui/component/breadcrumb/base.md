# breadcrumb控件

用于带有层次的导航，active状态表明当前页面的位置

# 如何使用

给父元素添加`.u-breadcrumb`,自定义导航结构的分隔符

# 示例



