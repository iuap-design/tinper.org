# 导航条

提供了几条常用的导航，包括基础导航、工具导航、图片导航、不同颜色导航。具体代码在[webIDE](http://tinper.org/webide/#/demos/ui/navbar)进行在线测试。


# 示例




[试一试](http://tinper.org/webide/#/demos/ui/navbar)