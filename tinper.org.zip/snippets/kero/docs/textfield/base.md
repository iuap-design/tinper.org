# 文本输入框

本例展示kero与文本输入框Textfield结合示例。

[试一试](http://tinper.org/webide/#/demos/kero/textfield)


# API

## \# u-meta 属性

* type：`u-text`