# 月日选择

本例展示:月日UI控件绑定默认数据。

[试一试](http://tinper.org/webide/#/demos/kero/monthdate)


# API

## \# u-meta 属性

* type：`u-monthdate`

u-meta基础api请参考[这里](http://tinper.org/dist/kero/docs/moduleapi.html)

相关内容：

[基础月日控件](http://tinper.org/dist/neoui/plugin/monthdate.html)
