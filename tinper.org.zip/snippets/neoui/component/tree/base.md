# tree控件

多层嵌套节点显示

# 插件依赖

依赖于 http://design.yonyoucloud.com/static/uui/latest/js/u.js

# 用法

1.创建id为`treeTest`父元素，并且配置`u-meta`

```
<div id="treeTest" class="ztree" u-meta='{"multiSelect":"true","id":"tree2","data":"dataTable","type":"tree","idField":"id","pidField":"pid","nameField":"title","setting":"treeSetting"}'></div>

```
2.js配置数据并绑定事件，详情见示例

# API

## js参数
data : 实际数据，自行配置数据结构

# 示例

