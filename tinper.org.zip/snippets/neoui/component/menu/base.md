# menu控件

动态弹出菜单

# 插件依赖

依赖于 http://design.yonyoucloud.com/static/uui/latest/js/u.js

# 用法

1.详情见于示例

# 示例





