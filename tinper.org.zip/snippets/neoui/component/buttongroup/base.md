# 按钮组

样式为`u-button-group`的父元素，包裹多个样式为`u-button`的button元素



[试一试](http://tinper.org/webide/#/demos/ui/buttongroup)