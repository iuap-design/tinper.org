# 按钮

为button元素添加`.u-button`即可实现一个按钮。其他效果的按钮实现只需添加相应的样式。




[试一试](http://tinper.org/webide/#/demos/ui/button)